

// import cards from "./card_data";
// import Card from "./Card";

const container = document.getElementById("root");
const root = ReactDOM.createRoot(container);
root.render(<App />);
